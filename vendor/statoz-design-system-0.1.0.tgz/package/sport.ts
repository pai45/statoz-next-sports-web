export type Sport='football'|'cricket'|'basketball'|'tennis'|'motorsport';
