import * as React from 'react';
import Link from "next/link";
import type { CSSProperties, ReactNode } from "react";

import styles from "./nav-rail.module.css";

type NavRailItemBase = {
  id: string;
  label: string;
  icon: ReactNode;
  /** Color the item takes when it is the current destination. */
  accent: string;
};

export type NavRailItem = NavRailItemBase &
  (
    | { href: string; onSelect?: never }
    | { href?: never; onSelect: () => void }
  );

export type NavRailProps = {
  items: NavRailItem[];
  /** Id of the current destination. */
  activeId?: string;
  /** `bar` lays the items out horizontally, `rail` stacks them vertically. */
  orientation?: "bar" | "rail";
  /** Rail only: a narrow icon column with small labels, for short landscape screens. */
  compact?: boolean;
  label: string;
  className?: string;
};

/**
 * Primary destination switcher, styled as a game loadout. Every destination is
 * an icon slot; only the current one glows. The same items render as a
 * bottom hotbar on small screens or a side rail on large ones, so the
 * navigation identity survives the reflow. A host that paints its own panel
 * behind the side rail sets `--nav-rail-panel` on it.
 */
export function NavRail({
  items,
  activeId,
  orientation = "bar",
  compact = false,
  label,
  className,
}: NavRailProps) {
  const rail = orientation === "rail";
  const variant = rail ? (compact ? "compact" : "rail") : "bar";
  const activeIndex = items.findIndex((item) => item.id === activeId);

  return (
    <nav
      aria-label={label}
      data-variant={variant}
      className={[styles.nav, className ?? ""].filter(Boolean).join(" ")}
      style={{ "--nav-accent": items[Math.max(activeIndex, 0)]?.accent } as CSSProperties}
    >
      <ul className={styles.list}>
        {items.map((item) => {
          const active = item.id === activeId;
          const itemStyle = { "--nav-accent": item.accent } as CSSProperties;
          const content = (
            <>
              {variant === "rail" ? <span className={styles.marker} aria-hidden="true" /> : null}
              <span className={styles.slot}><span className={styles.glyph}>{item.icon}</span></span>
              <span className={styles.label}>{item.label}</span>
            </>
          );
          return (
            <li key={item.id} className={styles.cell}>
              {item.href ? (
                <Link href={item.href} aria-current={active ? "page" : undefined} className={styles.item} data-active={active || undefined} style={itemStyle}>
                  {content}
                </Link>
              ) : (
                <button type="button" onClick={item.onSelect} aria-current={active ? "page" : undefined} className={styles.item} data-active={active || undefined} style={itemStyle}>
                  {content}
                </button>
              )}
            </li>
          );
        })}
      </ul>
    </nav>
  );
}
