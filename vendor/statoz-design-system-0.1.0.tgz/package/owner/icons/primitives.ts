/** Final-grid geometry: changing motif size never changes the shared stroke. */
export type IconGeometry = { paths: readonly string[]; fills: readonly string[] };
type Point = readonly [number, number];
const n = (value: number) => Number(value.toFixed(2));
const point = ([x, y]: Point) => `${n(x)} ${n(y)}`;
const polygon = (points: readonly Point[]) => `M${points.map(point).join("L")}Z`;

export const iconFamilySpec = { viewBox: "0 0 32 32", strokeWidth: 1.75, lineCap: "butt", lineJoin: "miter", miterLimit: 2, version: 3 } as const;

/** Twelve facets retain a round ball silhouette without a decorative frame. */
function ballOutline(cx: number, cy: number, radius: number) {
  return polygon(Array.from({ length: 12 }, (_, i) => {
    const angle = -Math.PI / 2 + i * Math.PI / 6;
    return [cx + radius * Math.cos(angle), cy + radius * Math.sin(angle)] as Point;
  }));
}
export function footballBall(cx: number, cy: number, radius: number, seams = false): IconGeometry {
  const panelRadius = radius * .46;
  const panel = Array.from({ length: 5 }, (_, i) => {
    const angle = -Math.PI / 2 + i * Math.PI * 2 / 5;
    return [cx + panelRadius * Math.cos(angle), cy + panelRadius * Math.sin(angle)] as Point;
  });
  return {
    paths: [ballOutline(cx, cy, radius), ...(seams ? [panel.map(([x, y], i) => {
      const angle = -Math.PI / 2 + i * Math.PI * 2 / 5;
      return `M${point([x, y])}L${point([cx + radius * .94 * Math.cos(angle), cy + radius * .94 * Math.sin(angle)])}`;
    }).join("")] : [])],
    fills: [polygon(panel)],
  };
}
export function basketballBall(cx: number, cy: number, r: number, full = false): IconGeometry {
  const edge = full ? .707 : .5;
  const rise = full ? .707 : .86;
  const bend = full ? -.2 : .65;
  return { paths: [ballOutline(cx, cy, r),
    `M${point([cx - r, cy])}H${n(cx + r)}M${point([cx - r * edge, cy - r * rise])}C${point([cx + r * bend, cy - r * .3])} ${point([cx + r * bend, cy + r * .3])} ${point([cx - r * edge, cy + r * rise])}`,
    ...(full ? [`M${point([cx, cy - r])}V${n(cy + r)}M${point([cx + r * edge, cy - r * rise])}C${point([cx - r * bend, cy - r * .3])} ${point([cx - r * bend, cy + r * .3])} ${point([cx + r * edge, cy + r * rise])}`] : []),
  ], fills: [] };
}
export function seamBall(cx: number, cy: number, r: number): IconGeometry {
  return { paths: [`M${n(cx - r)} ${cy}a${r} ${r} 0 1 0 ${r * 2} 0a${r} ${r} 0 1 0 ${-r * 2} 0Z`,
    `M${point([cx - r * .5, cy - r * .86])}Q${point([cx + r * .85, cy])} ${point([cx - r * .5, cy + r * .86])}`], fills: [] };
}

/** Anatomical bat: grip, two shoulders, broad blade and chamfered flat toe. */
export function cricketBat(cx = 15, cy = 3, scale = 1, cue = false): IconGeometry {
  const a = Math.PI / 9;
  const p = (x: number, y: number): Point => [cx + scale * (x * Math.cos(a) - y * Math.sin(a)), cy + scale * (x * Math.sin(a) + y * Math.cos(a))];
  const halfBlade = cue ? 4 : 3;
  const blade = polygon([p(-1.2, 7), p(1.2, 7), p(halfBlade, 9), p(halfBlade, 25), p(halfBlade - 1, 27), p(1 - halfBlade, 27), p(-halfBlade, 25), p(-halfBlade, 9)]);
  return cue
    ? { paths: [`M${point(p(0, 0))}L${point(p(0, 7))}`], fills: [blade] }
    : { paths: [polygon([p(-1.2, 0), p(1.2, 0), p(1.2, 7), p(-1.2, 7)]), blade,
      [2.3, 4.6].map(y => `M${point(p(-1.2, y))}L${point(p(1.2, y))}`).join("")], fills: [] };
}

/** A diagonal racket with a real throat; strings are deliberately sparse. */
export function tennisRacket(cx: number, cy: number, h: number, w: number, gripLength: number, strings = true): IconGeometry {
  const p = (u: number, v: number): Point => [cx + (u + v) / Math.SQRT2, cy + (v - u) / Math.SQRT2];
  const neck = h + 2.5;
  const halfGrip = w > 3 ? 1.3 : .9;
  return {
    paths: [polygon([p(-h, -w * .4), p(-h * .45, -w), p(h * .45, -w), p(h, -w * .4), p(h, w * .4), p(h * .45, w), p(-h * .45, w), p(-h, w * .4)]),
      `M${point(p(-h, -w * .4))}L${point(p(-neck, 0))}L${point(p(-h, w * .4))}`,
      ...(strings ? [`M${point(p(-h * .6, 0))}L${point(p(h * .6, 0))}M${point(p(0, -w * .8))}L${point(p(0, w * .8))}`] : []),
    ],
    fills: [polygon([p(-neck, -halfGrip), p(-neck, halfGrip), p(-neck - gripLength, halfGrip), p(-neck - gripLength, -halfGrip)])],
  };
}

/** Symmetric open-wheel plan view: four separated tyres, wings and cockpit. */
export const raceCar: IconGeometry = {
  paths: ["M14 3h4l2 7v5l3 5v5H9v-5l3-5v-5Z", "M8 7h16M7 28h18", "M7 13h5M20 13h5M7 23h3M22 23h3"],
  fills: ["M3 10h4v6H3ZM25 10h4v6h-4ZM3 20h4v7H3ZM25 20h4v7h-4Z", "M14 12l2-2 2 2v5h-4Z"],
};
export function questionMark(cx: number, top: number, s = 1): IconGeometry {
  const p = (x: number, y: number): Point => [cx + x * s, top + y * s];
  return { paths: [`M${point(p(-3.5, 4))}C${point(p(-3.5, -1))} ${point(p(3.5, -1))} ${point(p(3.5, 3))}C${point(p(3.5, 6))} ${point(p(0, 6))} ${point(p(0, 9))}`],
    fills: [polygon([p(-1, 12), p(1, 12), p(1, 14), p(-1, 14)])] };
}

export function combine(...geometries: IconGeometry[]): IconGeometry {
  return { paths: geometries.flatMap(g => g.paths), fills: geometries.flatMap(g => g.fills) };
}
