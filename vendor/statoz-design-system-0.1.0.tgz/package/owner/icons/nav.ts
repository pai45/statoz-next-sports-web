import { iconFamilySpec } from "./primitives";

/**
 * Original StatOz navigation glyphs for the studio's sidebar and mobile dock.
 * Same 32-unit family as the sport and game icons: chamfered silhouettes,
 * one dominant shape plus one solid cue, so each tab reads in monochrome.
 */
export const navIcons = {
  workspace: {
    name: "Workspace", motif: "Chamfered phone with an app grid",
    paths: ["M10 3H22L24 5V27L22 29H10L8 27V5Z", "M14 6.5H18M14 25.5H18"],
    fills: ["M11 10H15V14H11ZM17 10H21V14H17ZM11 16H15V20H11Z", "M17 16H21V20H17Z"],
  },
  "game-design": {
    name: "Game Design", motif: "Faceted gamepad with d-pad and action buttons",
    paths: ["M8 8H24L27 11L29 22L26 25L21 21H11L6 25L3 22L5 11Z"],
    fills: ["M9.5 12H11.5V13.5H13V15.5H11.5V17H9.5V15.5H8V13.5H9.5Z", "M21.5 11.5L23 13L21.5 14.5L20 13ZM24 14L25.5 15.5L24 17L22.5 15.5Z"],
  },
  releases: {
    name: "Releases", motif: "Launch rocket with fins and exhaust",
    paths: ["M16 3L20 8V20H12V8Z", "M12 14L8 18V23L12 20M20 14L24 18V23L20 20"],
    fills: ["M14.5 10.5L16 9L17.5 10.5L16 12Z", "M13.5 22H18.5L16 29Z"],
  },
  reports: {
    name: "Reports", motif: "Axis with three rising stat bars",
    paths: ["M5 4V27H28"],
    fills: ["M9 19H13V24H9Z", "M15.5 14H19.5V24H15.5Z", "M22 8H26V24H22Z"],
  },
  brands: {
    name: "Brands", motif: "Cut gem with a lit crown facet",
    paths: ["M9 5H23L28 12L16 28L4 12Z", "M4 12H28M10 12L16 28L22 12"],
    fills: ["M12 5H20L16 12Z"],
  },
  projects: {
    name: "Projects", motif: "Stacked design cards with a cover band",
    paths: ["M11 8V4H28V21H24", "M4 11L7 8H24V25L21 28H4Z", "M8 22H17"],
    fills: ["M8 12H20V18H8Z"],
  },
  "pitch-decks": {
    name: "Pitch decks", motif: "Presentation screen with a rising trend",
    paths: ["M3 5H29M5 5V20H27V5", "M16 20V24M11 28L16 24L21 28", "M9 16L13 12L16 14.5L21 9.5"],
    fills: ["M19 7.5H24V12.5Z"],
  },
  "investor-emails": {
    name: "Investor emails", motif: "Chamfered envelope with a diamond seal",
    paths: ["M3 9L6 6H26L29 9V23L26 26H6L3 23Z", "M3 9L12.5 16.5M29 9L19.5 16.5"],
    fills: ["M16 13L19.5 16.5L16 20L12.5 16.5Z"],
  },
  templates: {
    name: "Templates", motif: "Layout frame with columns and a hero block",
    paths: ["M4 7L7 4H28V25L25 28H4Z", "M4 11H28M12 11V28"],
    fills: ["M15 14H25V19H15Z"],
  },
  scheduler: {
    name: "Scheduler", motif: "Calendar page with a booked day",
    paths: ["M4 7H28V25L25 28H4Z", "M10 3V10M22 3V10", "M4 13H28"],
    fills: ["M17 17H23V23H17Z"],
  },
  assistant: {
    name: "Assistant", motif: "Speech plate with a creative spark",
    paths: ["M7 4H25L28 7V18L25 21H14L8 27V21H7L4 18V7Z"],
    fills: ["M16 6.5L17.4 11.1L22 12.5L17.4 13.9L16 18.5L14.6 13.9L10 12.5L14.6 11.1Z"],
  },
  assets: {
    name: "Assets", motif: "Image frame with peaks and a diamond sun",
    paths: ["M4 4H28V25L25 28H4Z"],
    fills: ["M4 24L11 15L16 21L19 18L25 24Z", "M21 7.5L23.5 10L21 12.5L18.5 10Z"],
  },
  exports: {
    name: "Exports", motif: "Drop arrow into an output tray",
    paths: ["M16 3V14", "M4 18V25L6 27H26L28 25V18"],
    fills: ["M10 13H22L16 20Z"],
  },
  "video-demos": {
    name: "Video demos", motif: "Chamfered screen with a play cue",
    paths: ["M6 5H29V24L26 27H3V8Z", "M3 22H29"],
    fills: ["M13 9L20.5 13.5L13 18Z"],
  },
  "switch-area": {
    name: "Switch area", motif: "Opposed transfer arrows",
    paths: ["M5 11H23", "M27 21H9"],
    fills: ["M22 6.5L28 11L22 15.5Z", "M10 16.5L4 21L10 25.5Z"],
  },
} as const satisfies Record<string, { name: string; motif: string; paths: readonly string[]; fills: readonly string[] }>;

export type NavIconId = keyof typeof navIcons;
export const navIconIds = Object.keys(navIcons) as NavIconId[];
export const navIconSpec = iconFamilySpec;

/** Standalone files accept currentColor or a resolved palette value, never markup. */
export function navIconSvg(id: NavIconId, color = "currentColor") {
  if (color !== "currentColor" && !/^#[\da-f]{6}$/i.test(color)) throw new Error("Use currentColor or a six-digit hex color.");
  const icon = navIcons[id];
  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="${navIconSpec.viewBox}" width="32" height="32" fill="none" stroke="${color}" stroke-width="${navIconSpec.strokeWidth}" stroke-linecap="${navIconSpec.lineCap}" stroke-linejoin="${navIconSpec.lineJoin}" stroke-miterlimit="${navIconSpec.miterLimit}" role="img" aria-label="${icon.name}"><title>StatOz ${icon.name}</title>${icon.paths.map(d => `<path d="${d}"/>`).join("")}${icon.fills.map(d => `<path d="${d}" fill="${color}" fill-rule="evenodd" stroke="none"/>`).join("")}</svg>\n`;
}
