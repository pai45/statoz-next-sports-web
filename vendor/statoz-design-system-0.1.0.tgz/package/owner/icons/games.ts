import snapshot from "./games.snapshot.json";
import type { Sport } from "@statoz/design-system/sport";
import { sportIcons } from "./sports";
import { customGameIcons, customGameIconSpec, type GameIconId } from "./games-custom";
export type { GameIconId } from "./games-custom";
export type GameIconVariant = "statoz" | "original";
export const gameIconVariants: readonly GameIconVariant[] = ["statoz", "original"];

/** Local source-faithful snapshot; card_game is never read at runtime. */
export const gameIconSource = {
  source: snapshot.source, catalogPath: snapshot.catalogPath, catalogSha256: snapshot.catalogSha256,
  fontPath: snapshot.fontPath, fontSha256: snapshot.fontSha256,
  attribution: snapshot.attribution, license: snapshot.license, licenseUrl: snapshot.licenseUrl,
};
export const gameIcons = snapshot.games.map(game => ({
  ...game, id: game.id as GameIconId, sport: game.sport as Sport, accent: sportIcons[game.sport as Sport].accent,
  ...snapshot.glyphs[game.glyph as keyof typeof snapshot.glyphs],
  ...customGameIcons[game.id as GameIconId],
}));
export const gameIconSpec = customGameIconSpec;
export const originalGameIconSpec = {
  viewBox: `0 0 ${snapshot.unitsPerEm} ${snapshot.unitsPerEm}`,
  transform: `translate(0 ${snapshot.ascent}) scale(1 -1)`, version: 1,
};
export function getGameIcon(id: GameIconId) {
  const icon = gameIcons.find(icon => icon.id === id);
  if (!icon) throw new Error(`Unknown game icon: ${id}`);
  return icon;
}
export function gameIconSvg(id: GameIconId, color = "currentColor", variant: GameIconVariant = "statoz") {
  if (color !== "currentColor" && !/^#[\da-f]{6}$/i.test(color)) throw new Error("Use currentColor or a resolved six-digit hex token");
  const icon = getGameIcon(id);
  if (variant === "original") return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="${originalGameIconSpec.viewBox}" width="24" height="24" fill="${color}"><title>${icon.name}</title><metadata>${gameIconSource.attribution} ${gameIconSource.licenseUrl}</metadata><path transform="${originalGameIconSpec.transform}" d="${icon.path}"/></svg>`;
  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="${gameIconSpec.viewBox}" width="24" height="24" fill="none" stroke="${color}" stroke-width="${gameIconSpec.strokeWidth}" stroke-linecap="${gameIconSpec.lineCap}" stroke-linejoin="${gameIconSpec.lineJoin}" stroke-miterlimit="${gameIconSpec.miterLimit}"><title>StatOz ${icon.name}</title><metadata>Original StatOz vector artwork. ${icon.motif}.</metadata>${icon.paths.map(d => `<path d="${d}"/>`).join("")}${icon.fills.map(d => `<path d="${d}" fill="${color}" fill-rule="evenodd" stroke="none"/>`).join("")}</svg>`;
}
