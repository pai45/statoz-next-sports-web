/** Browsers may shorten a hex token even when the source uses six digits. */
export function iconExportColor(value: string) {
  const color = value.trim();
  if (/^#[\da-f]{3}$/i.test(color)) return `#${[...color.slice(1)].map(channel => channel + channel).join("")}`;
  if (/^#[\da-f]{6}$/i.test(color)) return color;
  throw new Error("Icon exports need a resolved opaque hex color.");
}
