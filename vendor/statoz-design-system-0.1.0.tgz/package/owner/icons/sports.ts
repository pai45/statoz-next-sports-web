import type { Sport } from "@statoz/design-system/sport";
import { basketballBall, combine, cricketBat, footballBall, iconFamilySpec, raceCar, seamBall, tennisRacket } from "./primitives";

/** Original StatOz vector artwork. This geometry drives React and SVG downloads. */
export const sportIcons = {
  football: {
    name: "Football", motif: "Faceted match ball", accent: "--ds-color-accent-cyan",
    ...footballBall(16, 16, 12.5, true),
  },
  cricket: {
    name: "Cricket", motif: "Shouldered bat and seam ball", accent: "--ds-color-accent-white",
    ...combine(cricketBat(), seamBall(24, 24, 4.5)),
  },
  basketball: {
    name: "Basketball", motif: "Faceted court ball", accent: "--ds-color-accent-gold",
    ...basketballBall(16, 16, 12.5, true),
  },
  tennis: {
    name: "Tennis", motif: "Strung racket and seam ball", accent: "--ds-color-accent-lime",
    ...combine(tennisRacket(20, 11.5, 6.5, 5, 7), seamBall(25, 25, 3.5)),
  },
  motorsport: {
    name: "Motorsport", motif: "Open-wheel racer, wings and cockpit", accent: "--ds-color-accent-racing",
    ...raceCar,
  },
} as const satisfies Record<Sport, { name: string; motif: string; accent: string; paths: readonly string[]; fills: readonly string[] }>;

export const sportIconIds = Object.keys(sportIcons) as Sport[];
export const sportIconSpec = iconFamilySpec;

/** Standalone files accept currentColor or a resolved palette value, never markup. */
export function sportIconSvg(sport: Sport, color = "currentColor") {
  if (color !== "currentColor" && !/^#[\da-f]{6}$/i.test(color)) throw new Error("Use currentColor or a six-digit hex color.");
  const icon = sportIcons[sport];
  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="${sportIconSpec.viewBox}" width="32" height="32" fill="none" stroke="${color}" stroke-width="${sportIconSpec.strokeWidth}" stroke-linecap="${sportIconSpec.lineCap}" stroke-linejoin="${sportIconSpec.lineJoin}" stroke-miterlimit="${sportIconSpec.miterLimit}" role="img" aria-label="${icon.name}"><title>StatOz ${icon.name}</title>${icon.paths.map(d => `<path d="${d}"/>`).join("")}${icon.fills.map(d => `<path d="${d}" fill="${color}" fill-rule="evenodd" stroke="none"/>`).join("")}</svg>\n`;
}
