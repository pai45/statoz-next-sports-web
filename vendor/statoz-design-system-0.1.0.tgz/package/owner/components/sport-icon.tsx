import * as React from 'react';
import type { CSSProperties } from "react";
import type { Sport } from "@statoz/design-system/sport";
import { sportIcons, sportIconSpec } from "../icons/sports";

/** Decorative by default; supply a label when the icon carries meaning alone. */
export function SportIcon({ sport, size = 24, label, className, style }: { sport: Sport; size?: number; label?: string; className?: string; style?: CSSProperties }) {
  return <svg xmlns="http://www.w3.org/2000/svg" viewBox={sportIconSpec.viewBox} width={size} height={size} fill="none" stroke="currentColor" strokeWidth={sportIconSpec.strokeWidth} strokeLinecap={sportIconSpec.lineCap} strokeLinejoin={sportIconSpec.lineJoin} strokeMiterlimit={sportIconSpec.miterLimit} className={className} style={style} role={label ? "img" : undefined} aria-label={label} aria-hidden={label ? undefined : true} focusable="false">
    {label && <title>{label}</title>}{sportIcons[sport].paths.map((d, i) => <path key={i} d={d}/>)}
    {sportIcons[sport].fills.map((d, i) => <path key={`fill-${i}`} d={d} fill="currentColor" fillRule="evenodd" stroke="none"/>)}
  </svg>;
}
