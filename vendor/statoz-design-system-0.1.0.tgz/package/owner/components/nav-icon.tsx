import * as React from 'react';
import type { CSSProperties } from "react";
import { navIcons, navIconSpec, type NavIconId } from "../icons/nav";

/** Decorative by default; supply a label when the icon carries meaning alone. */
export function NavIcon({ id, size = 24, label, className, style }: { id: NavIconId; size?: number; label?: string; className?: string; style?: CSSProperties }) {
  const icon = navIcons[id];
  return <svg xmlns="http://www.w3.org/2000/svg" viewBox={navIconSpec.viewBox} width={size} height={size} fill="none" stroke="currentColor" strokeWidth={navIconSpec.strokeWidth} strokeLinecap={navIconSpec.lineCap} strokeLinejoin={navIconSpec.lineJoin} strokeMiterlimit={navIconSpec.miterLimit} className={className} style={style} role={label ? "img" : undefined} aria-label={label} aria-hidden={label ? undefined : true} focusable="false">
    {label && <title>{label}</title>}{icon.paths.map((d, i) => <path key={i} d={d}/>)}
    {icon.fills.map((d, i) => <path key={`fill-${i}`} d={d} fill="currentColor" fillRule="evenodd" stroke="none"/>)}
  </svg>;
}
