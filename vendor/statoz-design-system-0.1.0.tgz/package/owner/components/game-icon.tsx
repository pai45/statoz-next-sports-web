import * as React from 'react';
import type { CSSProperties } from "react";
import { gameIconSpec, originalGameIconSpec, getGameIcon, type GameIconId, type GameIconVariant } from "../icons/games";

/** Decorative by default. Preview and downloads share the same geometry. */
export function GameIcon({ game, variant = "statoz", size = 24, label, className, style }: { game: GameIconId; variant?: GameIconVariant; size?: number; label?: string; className?: string; style?: CSSProperties }) {
  const icon = getGameIcon(game);
  const original = variant === "original";
  return <svg xmlns="http://www.w3.org/2000/svg" viewBox={original ? originalGameIconSpec.viewBox : gameIconSpec.viewBox} width={size} height={size} fill={original ? "currentColor" : "none"} stroke={original ? undefined : "currentColor"} strokeWidth={original ? undefined : gameIconSpec.strokeWidth} strokeLinecap={gameIconSpec.lineCap} strokeLinejoin={gameIconSpec.lineJoin} strokeMiterlimit={gameIconSpec.miterLimit} className={className} style={style} role={label ? "img" : undefined} aria-label={label} aria-hidden={label ? undefined : true} focusable="false">
    {label && <title>{label}</title>}{original ? <path transform={originalGameIconSpec.transform} d={icon.path}/> : <>{icon.paths.map((d, i) => <path key={i} d={d}/>)}{icon.fills.map((d, i) => <path key={`fill-${i}`} d={d} fill="currentColor" fillRule="evenodd" stroke="none"/>)}</>}
  </svg>;
}
