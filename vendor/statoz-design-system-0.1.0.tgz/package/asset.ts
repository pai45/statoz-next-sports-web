export const publicAsset=(value:string)=>(process.env.NEXT_PUBLIC_BASE_PATH||'')+value;
