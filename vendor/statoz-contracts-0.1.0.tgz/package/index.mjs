export const integrationVersion=1;
export function moduleDescriptor(value){if(!value||value.schemaVersion!==1||!value.id||!value.version||!Array.isArray(value.operations))throw Error('Invalid module descriptor');return value;}
export function catalogue(value){if(value?.schemaVersion!==1||!Array.isArray(value.games)||new Set(value.games.map(g=>g.id)).size!==value.games.length)throw Error('Invalid game catalogue');for(const g of value.games){if(!/^[a-z0-9-]+$/.test(g.id)||!g.entry||g.hostProtocol!==1||!g.saveSchema)throw Error('Invalid game entry');}return value;}
