export type ModuleDescriptor={schemaVersion:1,id:string,version:string,integrationVersion:1,navigation:{title:string,href:string}[],operations:string[],ready:boolean};
export type JobRecord={schemaVersion:1,id:string,operation:string,inputs:unknown,state:'queued'|'running'|'complete'|'failed',outputs:unknown[],error?:string};
export type GameCatalogue={schemaVersion:1,revision:string,games:{id:string,title:string,sport:string,entry:string,hostProtocol:1,saveSchema:number,runtimeVersion:string,sha256:string}[]};
export function moduleDescriptor(value:unknown):ModuleDescriptor;
export function catalogue(value:unknown):GameCatalogue;
export const integrationVersion:1;
