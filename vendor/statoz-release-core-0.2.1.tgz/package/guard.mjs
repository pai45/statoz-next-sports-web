import fs from 'node:fs';
import path from 'node:path';
import {syncBuiltinESMExports} from 'node:module';
import {fileURLToPath} from 'node:url';
const config=process.env.STATOZ_MODULE_CONFIG;if(config){
 const m=JSON.parse(fs.readFileSync(config,'utf8')),legacyProfiles=[process.env.LOCALAPPDATA&&path.join(process.env.LOCALAPPDATA,'StatOz Designer'),process.env.USERPROFILE&&path.join(process.env.USERPROFILE,'.statoz-designer')].filter(Boolean),roots=[...(m.protectedRoots||[]),...legacyProfiles].map(p=>path.resolve(p).toLowerCase());
 const target=value=>{if(typeof value==='number'||value===undefined)return;const raw=value instanceof URL?fileURLToPath(value):String(value),resolved=path.resolve(raw).toLowerCase();let real=resolved,current=path.resolve(raw);while(!fs.existsSync(current)&&path.dirname(current)!==current)current=path.dirname(current);try{real=path.resolve(fs.realpathSync(current),path.relative(current,path.resolve(raw))).toLowerCase();}catch{}if(roots.some(root=>[resolved,real].some(p=>p===root||p.startsWith(root+path.sep))))throw Error('Protected original is read-only: '+raw);};
 const methods={writeFile:[0],appendFile:[0],mkdir:[0],rmdir:[0],rm:[0],unlink:[0],rename:[0,1],copyFile:[1],cp:[1],truncate:[0],chmod:[0],chown:[0],utimes:[0],link:[0,1],symlink:[1]};
 for(const [name,indices]of Object.entries(methods))for(const object of [fs,fs.promises])if(typeof object[name]==='function'){const original=object[name].bind(object);object[name]=(...args)=>{for(const i of indices)target(args[i]);return original(...args);};}
 for(const [name,indices]of Object.entries(methods)){const key=name+'Sync';if(typeof fs[key]==='function'){const original=fs[key].bind(fs);fs[key]=(...args)=>{for(const i of indices)target(args[i]);return original(...args);};}}
 for(const object of [fs,fs.promises]){const original=object.open.bind(object);object.open=(name,flags,...args)=>{if(typeof flags==='number'?Boolean(flags&(fs.constants.O_WRONLY|fs.constants.O_RDWR|fs.constants.O_CREAT|fs.constants.O_TRUNC)):typeof flags==='string'&&/[wa+]/.test(flags))target(name);return original(name,flags,...args);};}
 const open=fs.openSync.bind(fs);fs.openSync=(name,flags,...args)=>{if(typeof flags==='number'?Boolean(flags&(fs.constants.O_WRONLY|fs.constants.O_RDWR|fs.constants.O_CREAT|fs.constants.O_TRUNC)):typeof flags==='string'&&/[wa+]/.test(flags))target(name);return open(name,flags,...args);};
 const stream=fs.createWriteStream.bind(fs);fs.createWriteStream=(name,...args)=>{target(name);return stream(name,...args);};syncBuiltinESMExports();
}
