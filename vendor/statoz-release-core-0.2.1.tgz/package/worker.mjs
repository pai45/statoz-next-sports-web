import fs from 'node:fs/promises';
import path from 'node:path';
import os from 'node:os';
import {execFileSync} from 'node:child_process';
import {configuration,argsOf,readJson,atomicJson,spawnCommand,within,invoked} from './common.mjs';
const scripts={renderer:'src/server/worker.ts',assistant:'src/server/agent.ts',publisher:'src/server/publisher.ts',scheduler:'src/server/scheduler.ts',reports:'src/server/reports/worker.ts'};
const heartbeat={renderer:'worker.json',assistant:'agent.json',publisher:'publisher.json',scheduler:'scheduler.json',reports:'reports/worker.json'};
export async function main(argv=process.argv.slice(2)){
 const args=argsOf(argv),m=await configuration(),local=await readJson(path.join(m.root,'module.local.json'),{}),service=String(args.service||'');
 const allowed=new Set(m.id==='reports'?['reports']:['marketing','investors'].includes(m.id)?['renderer','assistant','publisher','scheduler']:[]);if(!allowed.has(service))throw Error('Select a worker owned by this module with --service NAME');
 const scheduled=local.scheduledWorker;if(service==='scheduler'&&(!scheduled?.enabled||scheduled.pc!==os.hostname()||!Array.isArray(scheduled.accounts)||!scheduled.accounts.length))throw Error('Scheduled work is disabled. Assign this PC and the operating accounts in module.local.json before enabling it.');
 const port=Number(local.port||m.port),profile=path.resolve(process.env.PUBLISH_PROFILE_DIR||path.join(m.dataRoot,'browser-profiles/publisher'));if(!within(m.dataRoot,profile))throw Error('Publisher profiles must stay inside this module private data root.');
 const env={...process.env,PORT:String(port),STATOZ_MODULE_ID:m.id,STATOZ_MODULE_NAME:m.name,STATOZ_MODULE_PORT:String(port),STUDIO_DATA_DIR:m.dataRoot,STATOZ_WORKSPACE_ROOT:path.dirname(m.root),STATOZ_MODULE_CONFIG:path.join(m.root,'module.json'),PUBLISH_PROFILE_DIR:profile,STATOZ_SCHEDULES_ENABLED:service==='scheduler'?'true':'false'};env.NODE_OPTIONS=[process.env.NODE_OPTIONS||'',`--import ${new URL('./guard.mjs',import.meta.url).href}`].join(' ').trim();
 await fs.mkdir(m.dataRoot,{recursive:true});const owned=new Map();let stopping=false,scanning=false;const requests=path.join(m.dataRoot,'platform/companion',`${port}.service-requests`),receipt=path.join(m.dataRoot,'background-worker.json');
 const record=()=>atomicJson(receipt,{schemaVersion:1,module:m.id,pid:process.pid,pc:os.hostname(),service,owned:[...owned].map(([service,p])=>({service,pid:p.pid})),updatedAt:new Date().toISOString()});
 async function start(name){if(owned.has(name))return;const beat=await readJson(path.join(m.dataRoot,heartbeat[name]),null);if(beat&&Date.now()-Date.parse(beat.time)<15000){try{process.kill(beat.pid,0);return;}catch{}}
  const child=spawnCommand(process.execPath,['--import','tsx',scripts[name]],{cwd:m.root,env});owned.set(name,child);child.on('error',error=>console.error('Worker failed: '+error.message));child.on('exit',code=>{owned.delete(name);if(!stopping&&code)console.error(name+' stopped with '+code);void record();});await record();
 }
 const stop=()=>{if(stopping)return;stopping=true;clearInterval(timer);for(const child of owned.values()){if(child.exitCode!==null||!child.pid)continue;try{if(process.platform==='win32')execFileSync('taskkill.exe',['/PID',String(child.pid),'/T','/F'],{stdio:'ignore',windowsHide:true});else child.kill('SIGTERM');}catch{}}void fs.rm(receipt,{force:true});};
 const timer=setInterval(async()=>{if(stopping||scanning)return;scanning=true;try{for(const name of await fs.readdir(requests).catch(()=>[])){if(!name.endsWith('.json'))continue;const file=path.join(requests,name),request=await readJson(file,null);if(request?.status!=='requested')continue;if(!allowed.has(request.service)||request.service==='scheduler'&&service!=='scheduler'){await atomicJson(file,{...request,status:'rejected',error:'Worker does not own this operation or scheduled work is disabled'});continue;}await start(request.service);await atomicJson(file,{...request,status:'started'});}await record();}catch(error){console.error(error.message);}finally{scanning=false;}},900);
 process.once('SIGINT',stop);process.once('SIGTERM',stop);await start(service);console.log(`StatOz ${m.name} ${service} worker is running independently. No application server was started. Ctrl+C stops only workers owned by this command.`);
}
if(invoked(import.meta.url))main().catch(error=>{console.error(error.message);process.exitCode=1;});
