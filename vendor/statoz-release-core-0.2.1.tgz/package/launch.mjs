import fs from 'node:fs/promises';
import path from 'node:path';
import net from 'node:net';
import {execFileSync} from 'node:child_process';
import {fileURLToPath} from 'node:url';
import {configuration,argsOf,exists,spawnCommand,run,atomicJson,invoked,within} from './common.mjs';
export function portAvailable(port,host='127.0.0.1') {return new Promise((resolve,reject)=>{const server=net.createServer();server.once('error',e=>reject(Error(`Port ${port} is occupied or unavailable (${e.code}). Stop its owner or explicitly configure another port.`)));server.listen(port,host,()=>server.close(resolve));});}
async function browser(url) {if(process.platform==='win32'){const child=spawnCommand('powershell.exe',['-NoProfile','-WindowStyle','Hidden','-Command','Start-Process -FilePath '+"'"+url.replaceAll("'","''")+"'"],{stdio:'ignore'});child.unref();}else{const child=spawnCommand(process.platform==='darwin'?'open':'xdg-open',[url],{stdio:'ignore'});child.unref();}}
export async function flutterPath(m) {for(const file of [process.env.STATOZ_FLUTTER_PATH,m.flutterPath,'C:/develop/flutter/bin/flutter.bat'].filter(Boolean))if(await exists(file))return file;throw Error('Flutter SDK not found. Set STATOZ_FLUTTER_PATH to an independent Flutter 3.47.2 installation.');}
export async function main(argv=process.argv.slice(2)) {
  const args=argsOf(argv),action=args._[0]||'dev',m=await configuration();
  const localConfig=await fs.readFile(path.join(m.root,'module.local.json'),'utf8').then(JSON.parse).catch(e=>{if(e.code==='ENOENT')return {};throw e;});
  const port=Number(localConfig.port||m.port);if(!Number.isInteger(port)||port<1024||port>65535)throw Error('Invalid configured port');
  const env={...process.env,PORT:String(port),STATOZ_MODULE_ID:m.id,STATOZ_MODULE_NAME:m.name,STATOZ_MODULE_PORT:String(port),STUDIO_DATA_DIR:m.dataRoot,STATOZ_GAME_STUDIO:m.kind==='studio'?'true':'false',STATOZ_WORKSPACE_ROOT:path.dirname(m.root),STATOZ_SCHEDULES_ENABLED:process.env.STATOZ_SCHEDULES_ENABLED||'false',STUDIO_PAGES_URL:`https://pai45.github.io/${m.repository.split('/')[1]}/`,NEXT_TELEMETRY_DISABLED:'1'};
  if(m.kind==='owner'){env.PUBLISH_PROFILE_DIR=path.resolve(process.env.PUBLISH_PROFILE_DIR||path.join(m.dataRoot,'browser-profiles/publisher'));if(!within(m.dataRoot,env.PUBLISH_PROFILE_DIR))throw Error('Publisher profiles must stay inside this module private data root.');}
  if(localConfig.gameCatalogueUrl)env.NEXT_PUBLIC_GAME_CATALOGUE_URL=localConfig.gameCatalogueUrl;
  if(m.kind==='studio')env.STATOZ_OWNER_TOOL='true';
  env.STATOZ_MODULE_CONFIG=path.join(m.root,'module.json');
  env.NODE_OPTIONS=[process.env.NODE_OPTIONS||'',`--import ${new URL('./guard.mjs',import.meta.url).href}`].join(' ').trim();
  if(action==='doctor'){console.log(JSON.stringify({module:m.id,port,url:`http://127.0.0.1:${port}`,dataRoot:m.dataRoot,independent:true,flutter:m.kind==='flutter'?await flutterPath(m).catch(e=>e.message):null},null,2));return;}
  if(['check','source-check','build'].includes(action)) {
    if(m.kind==='flutter'){const sdk=await flutterPath(m);await run(sdk,['pub','get','--enforce-lockfile'],{cwd:m.root,env});if(action!=='build'){await run(sdk,['analyze','--no-pub'],{cwd:m.root,env});if(action==='check')await run(sdk,['test','--no-pub'],{cwd:m.root,env});else await run(process.execPath,['--test','tests/operations/source.test.mjs','tests/operations/packages.test.mjs'],{cwd:m.root,env});}else await run(sdk,['build','web','--release','--no-pub','--base-href',`/${m.repository.split('/')[1]}/`],{cwd:m.root,env});return;}
    for(const item of m.commands?.[action]||(action==='source-check'?m.commands?.check:[])||[])await run(item[0]==='node'?process.execPath:item[0],item.slice(1),{cwd:m.root,env});return;
  }
  if(!['dev','start','native'].includes(action))throw Error('Use dev, start, native, check, build, or doctor');
  if(action!=='native')await portAvailable(port);
  await fs.mkdir(m.dataRoot,{recursive:true});
  let command=process.execPath,commandArgs;
  if(m.kind==='flutter') {
    command=await flutterPath(m);
    commandArgs=['run',...(action==='native'?[]:['-d',args['no-open']?'web-server':'chrome','--web-hostname','127.0.0.1','--web-port',String(port)]),...(args.device?['-d',String(args.device)]:[])];
    if(m.id==='games-app'){const requested=args['local-web']?`http://${action==='native'?'10.0.2.2':'127.0.0.1'}:4406/`:localConfig.gamesWebUrl||`https://pai45.github.io/statoz-next-games-web/`;commandArgs.push('--dart-define=GAMES_WEB_URL='+requested);}
  }else if(m.kind==='games')commandArgs=['scripts/games-dev.mjs',`--port=${port}`,...(args.game?[`--game=${args.game}`]:[])];
  else if(m.kind==='studio')commandArgs=['scripts/studio-dev.mjs',`--port=${port}`,...(action==='start'?['--production']:[])];
  else {const bin=path.join(m.root,'node_modules/next/dist/bin/next');if(!await exists(bin))throw Error('Dependencies are missing. Run npm run setup in this repository.');commandArgs=[bin,action==='start'?'start':'dev',...(action==='dev'?['--webpack']:[]),'--hostname','127.0.0.1','--port',String(port)];}
  const owned=new Set(),child=spawnCommand(command,commandArgs,{cwd:m.root,env});owned.add(child);
  let stopping=false;const stop=()=>{if(stopping)return;stopping=true;for(const p of owned){if(p.exitCode!==null||!p.pid)continue;try{if(process.platform==='win32')execFileSync('taskkill.exe',['/PID',String(p.pid),'/T','/F'],{stdio:'ignore',windowsHide:true});else p.kill('SIGTERM');}catch{}}};
  process.once('SIGINT',stop);process.once('SIGTERM',stop);
  child.on('error',e=>{console.error(e.message);stop();process.exitCode=1;});
  child.on('exit',code=>{stop();process.exitCode=code||0;});
  const services=new Map();
  const allowed=new Set(m.id==='reports'?['reports']:m.id==='marketing'?['renderer','assistant','publisher','scheduler']:m.id==='investors'?['renderer','assistant','publisher','scheduler']:[]);
  const serviceArgs={renderer:['--import','tsx','src/server/worker.ts'],assistant:['--import','tsx','src/server/agent.ts'],publisher:['--import','tsx','src/server/publisher.ts'],scheduler:['--import','tsx','src/server/scheduler.ts'],reports:['--import','tsx','src/server/reports/worker.ts']};
  const requestDir=path.join(m.dataRoot,'platform/companion',`${port}.service-requests`);
  const serviceState=Object.fromEntries(['web','renderer','assistant','publisher','scheduler','reports'].map(id=>[id,{state:id==='web'?'starting':'idle',attempts:0,detail:id==='web'?'Starting selected application':'Starts only when requested'}]));
  const publishStatus=()=>atomicJson(path.join(m.dataRoot,'platform/companion',`${port}.services.json`),{schemaVersion:1,port,phase:serviceState.web.state==='ready'?'editor-ready':'starting',startedAt:new Date().toISOString(),editorReady:serviceState.web.state==='ready',services:serviceState,updatedAt:new Date().toISOString()});
  await publishStatus();
  let scanning=false;
  const watcher=setInterval(async()=>{if(stopping||scanning)return;scanning=true;try{for(const entry of await fs.readdir(requestDir).catch(()=>[])){if(!entry.endsWith('.json'))continue;const file=path.join(requestDir,entry),request=await fs.readFile(file,'utf8').then(JSON.parse).catch(()=>null);if(!request||request.status!=='requested')continue;if(!allowed.has(request.service)){await atomicJson(file,{...request,status:'rejected',error:'Service does not belong to this module'});continue;}if(request.service==='scheduler'&&env.STATOZ_SCHEDULES_ENABLED!=='true'){await atomicJson(file,{...request,status:'rejected',error:'New schedules are disabled; explicitly enable this module on the assigned PC.'});continue;}if(!services.has(request.service)){const proc=spawnCommand(process.execPath,serviceArgs[request.service],{cwd:m.root,env});owned.add(proc);services.set(request.service,proc);serviceState[request.service]={state:'starting',attempts:(serviceState[request.service]?.attempts||0)+1,pid:proc.pid};proc.once('spawn',()=>{serviceState[request.service].state='ready';void publishStatus();});proc.once('error',error=>{serviceState[request.service]={...serviceState[request.service],state:'failed',detail:error.message};void publishStatus();});proc.once('exit',code=>{owned.delete(proc);services.delete(request.service);serviceState[request.service]={...serviceState[request.service],state:code?'failed':'stopped'};void publishStatus();});}await atomicJson(file,{...request,status:'started'});await publishStatus();}}catch(error){console.error('Service request failed: '+error.message);}finally{scanning=false;}},900);
  watcher.unref();child.once('exit',()=>clearInterval(watcher));
  const url=`http://127.0.0.1:${port}`;
  console.log(`\nStatOz ${m.name}: ${url}\nOnly ${m.name} is started. Ctrl+C stops its owned processes.\n`);
  if(action!=='native')for(let attempt=0;attempt<180&&!stopping;attempt++) {try{const r=await fetch(url,{signal:AbortSignal.timeout(2000)});if(r.ok){serviceState.web={state:'ready',attempts:1,pid:child.pid};await publishStatus();await atomicJson(path.join(m.dataRoot,'running.json'),{module:m.id,pid:process.pid,port,url,startedAt:new Date().toISOString()});if(!args['no-open']&&m.kind!=='flutter')await browser(url);break;}}catch{}await new Promise(r=>setTimeout(r,500));}
}
if(invoked(import.meta.url))main().catch(e=>{console.error(e.message);process.exitCode=1;});
