﻿import type { Sport } from "@statoz/design-system/sport";
import { basketballBall, combine, cricketBat, footballBall, iconFamilySpec, questionMark, raceCar, seamBall, tennisRacket, type IconGeometry } from "./primitives";

export type GameGeometry = IconGeometry & { motif: string };
export const customGameIconSpec = iconFamilySpec;

/** Each cue is drawn at final grid size; all related games use the same cue. */
const markers: Record<Sport, IconGeometry> = {
  football: footballBall(25, 25, 4.5),
  cricket: cricketBat(27, 20, .34, true),
  basketball: basketballBall(25, 25, 4.5),
  motorsport: {
    paths: ["M20 29v-4a5 5 0 0 1 5-5h1l3 3v3h-6v3Z"],
    fills: ["M24 22h2l2 2h-4Z"],
  },
  tennis: tennisRacket(26, 24, 3, 2, 2, false),
};
const quizFrame: IconGeometry = {
  paths: ["M7 3h16l4 4v9l-3 3h-5l-3 3v7H7l-4-4V7Z"], fills: [],
};
function quiz(sport: Sport, motif: string): GameGeometry {
  return { motif, ...combine(quizFrame, questionMark(12, 6), markers[sport]) };
}
function player(sport: "football" | "cricket" | "basketball", motif: string): GameGeometry {
  const shirt: IconGeometry = {
    paths: sport === "basketball"
      ? ["M6 3h5c0 5 8 5 8 0h5v7l-3 4v5h-4v10H9V14l-3-4Z"]
      : ["M10 4h10l3 3 6 3-3 6-5-3v6h-4v10H9V13l-4 3-3-6 5-3Z", "M11 4l4 4 4-4"],
    fills: [],
  };
  return { motif, ...combine(shirt, questionMark(14, 10, .75), markers[sport]) };
}

/** Original StatOz artwork. Imported app glyphs remain in games.snapshot.json. */
export const customGameIcons = {
  "pitch-duel": {
    motif: "Layered chamfered cards and football panel",
    ...combine({
      paths: ["M6 23H3V7l4-4h14l3 3v1", "M13 9h12l4 4v12l-4 4H13l-4-4V13Z"], fills: [],
    }, footballBall(19, 19, 5.5, true)),
  },
  "penalty-shootout": {
    motif: "Goal mouth, football and rising shot",
    ...combine({
      paths: ["M3 20V7l3-3h20l3 3v13M7 9h18M16 9v6", "M17 26l9-9M21 17h5v5"], fills: [],
    }, footballBall(8.5, 24.5, 4.5)),
  },
  "football-quiz": quiz("football", "Question card and football panel cue"),
  "football-guess-player": player("football", "Anonymous shirt and football panel cue"),
  "football-bingo": {
    motif: "Even nine-cell board and completed diagonal",
    paths: ["M7 4h18l3 3v18l-3 3H7l-3-3V7Z", "M4 12h24M4 20h24M12 4v24M20 4v24"],
    fills: ["M7 6h3v4H6V7ZM14 14h4v4h-4ZM22 22h4v3l-1 1h-3Z"],
  },
  "football-chess": {
    motif: "Tactical pitch, opposing players and move arrow",
    paths: ["M7 4h18l3 3v18l-3 3H7l-3-3V7Z", "M12 4v3h8V4M12 28v-3h8v3M4 16h6M22 16h6", "M12 23l8-12M15 11h5v5", "M22 7h4v4h-4Z"],
    fills: ["M6 20h4v4H6Z"],
  },
  "final-over": {
    motif: "Shouldered bat, three stumps and split bails",
    ...combine(cricketBat(), {
      paths: ["M20 13v16M24 13v16M28 13v16M19 10h4M25 10h4"], fills: [],
    }),
  },
  "cricket-quiz": quiz("cricket", "Question card and shouldered bat cue"),
  "cricket-guess-player": player("cricket", "Anonymous shirt and shouldered bat cue"),
  "hoop-duel": {
    motif: "Curved-seam basketball, rim and net",
    ...combine(basketballBall(10.5, 10.5, 7.5), {
      paths: ["M24 6h5v9", "M18 18h11l-2 3h-7Z", "M20 21l2 7h3l2-7M23.5 21v7"], fills: [],
    }),
  },
  "basketball-quiz": quiz("basketball", "Question card and curved-seam ball cue"),
  "basketball-guess-player": player("basketball", "Sleeveless jersey and curved-seam ball cue"),
  "grand-prix-dash": {
    motif: "Four-wheel racer and rear speed strokes",
    ...combine(raceCar, { paths: ["M11 30h3M18 30h3"], fills: [] }),
  },
  "motorsport-quiz": quiz("motorsport", "Question card and profile helmet cue"),
  "guess-driver": {
    motif: "Racing helmet and negative-space visor question",
    paths: ["M7 26l-3-8v-5C4 7 8 3 16 3s12 4 12 10v5l-3 8-5 3h-8Z", "M12 26h8"],
    fills: ["M7 11h18l1 3-2 10H8L6 14ZM11 15c0-2 2-3 5-3s5 1 5 3c0 2-4 2-4 4h-2c0-3 4-3 4-4 0-.7-1-1-3-1s-3 .3-3 1ZM15 20h2v2h-2Z"],
  },
  "tennis-rally": {
    motif: "Strung racket, seam ball and short net",
    ...combine(tennisRacket(14, 11, 6, 4, 6), seamBall(25, 7, 3), {
      paths: ["M18 21h11M18 21v8M29 21v8M18 25h11M23.5 21v8"], fills: [],
    }),
  },
  "tennis-quiz": quiz("tennis", "Question card and racket-throat cue"),
  "guess-winner": {
    motif: "Question trophy and tennis-ball base cue",
    ...combine({
      paths: ["M8 3h16v9l-6 8h-4l-6-8Z", "M8 6H3v5l5 5M24 6h5v5l-5 5M16 20v8M10 29h11"], fills: [],
    }, questionMark(16, 6, .7), seamBall(26, 26, 3.5)),
  },
} as const satisfies Record<string, GameGeometry>;
export type GameIconId = keyof typeof customGameIcons;
